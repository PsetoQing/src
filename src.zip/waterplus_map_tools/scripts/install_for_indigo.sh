#!/bin/bash
sudo apt-get update
sudo apt-get install ros-indigo-map-server
sudo apt-get install ros-indigo-navigation