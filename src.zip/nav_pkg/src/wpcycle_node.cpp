#include <ros/ros.h>
#include <std_msgs/String.h>
#include <vector>
#include <string>

// 当前航点索引
int current_waypoint_index = 0;
// 航点列表
std::vector<std::string> waypoints = {"1", "2", "3"};
// 是否收到导航结果
bool navigation_complete = true;

// 导航结果回调函数
void NavResultCallback(const std_msgs::String &msg)
{
    ROS_WARN("[NavResultCallback] %s", msg.data.c_str());
    if (msg.data == "done")
    {
        navigation_complete = true; // 标记导航已完成
    }
}
//可以关闭了
int main(int argc, char **argv)
{
    ros::init(argc, argv, "wpcycle_node");
    ros::NodeHandle n;
    ros::Publisher nav_pub = n.advertise<std_msgs::String>("/waterplus/navi_waypoint", 10);
    ros::Subscriber res_sub = n.subscribe("/waterplus/navi_result", 10, NavResultCallback);
     sleep(1);

    ros::Rate rate(1); // 控制循环频率

    while (ros::ok())
    {
        if (navigation_complete) // 检查导航是否完成
        {
            // 发送下一个航点
            std_msgs::String nav_msg;
            nav_msg.data = waypoints[current_waypoint_index];
            nav_pub.publish(nav_msg);
            ROS_INFO("Navigating to waypoint: %s", waypoints[current_waypoint_index].c_str());

            // 更新到下一个航点索引
            ROS_WARN(" current_waypoint_index is: %d", current_waypoint_index);
            current_waypoint_index = (current_waypoint_index + 1) % waypoints.size();
             ROS_ERROR("next Navigating to waypoint: %s", waypoints[current_waypoint_index].c_str());
            navigation_complete = false; // 重置导航完成标志
            
            
        }

        ros::spinOnce(); // 处理回调函数
        rate.sleep();    // 控制循环频率
    }

    return 0;
}