#include<ros/ros.h>
#include<std_msgs/String.h>
#include</home/dachuang/catkin_ws/devel/include/qq_msgs/Carry.h>

int main(int argc, char *argv[])
{   ros::init(argc,argv,"chao_node");
    printf("今天中午炒牛肉!\n");


    ros::NodeHandle nh;
    ros::Publisher pub=nh.advertise<qq_msgs::Carry>("LUNCH",10);
    ros::Rate loop_rate(10);
    while(ros::ok())
    {
        printf("小炒黄牛肉\n");
        qq_msgs::Carry msg;
        msg.grade="王者";
        msg.star=50;
        msg.data="吃完美滋滋";
        pub.publish(msg);
        loop_rate.sleep();
    }
    return 0;
     
}

